// Write a program to collect username and password from the user and validate it 
// against predefined values and if it is true then display menu to the user and ask for his/her
// choice to buy things. Allow consumer to buy multiple items until he/she wants to exit.
// get price list from file and generate bill at last add 7% tax to the total amount.
#include <stdio.h>
#include <string.h>

int main(){
    char username[50],password[50];
    printf("Enter username and password:\n");
    scanf("%s %s",username,password);

    if((strcmp(username,"raghav")==0) && (strcmp(password,"raghav@2025")==0)){
        printf("Login successful!\n");
    } else {
        printf("Invalid username or password.\n");
        return 0;
    }
    FILE *menu = fopen("menu.txt", "r");
    if (menu == NULL) {
        printf("Could not open menu file.\n");
        return 1;
    }
    char item[50],item1[50];
    float price;
    float total = 0.0;
    int quantity;
    printf("---------------------------\n");
    printf("Welcome to the shop! Here is the menu:\n");
    printf("---------------------------\n");
    while (fscanf(menu, "%s %f", item, &price) != EOF) {
        printf("%s: $%.2f\n", item, price);
    }
    printf("---------------------------\n");
    printf("Do you wish to buy an item? (y/n): ");
    char choice;
    scanf(" %c", &choice);
    while (choice == 'y' || choice == 'Y') {
        printf("Enter item name: ");
        scanf("%s", item1);
        printf("Enter quantity: ");
        scanf("%d", &quantity);
        rewind(menu);
        int found = 0;
        while (fscanf(menu, "%s %f", item, &price) != EOF) {
            if (strcmp(item1, item) == 0) {
                total += price * quantity;
                found = 1;
                break;
            }
        }
        if (!found) {
            printf("Item not found in menu.\n");
        }
        printf("Do you wish to buy another item? (y/n): ");
        scanf(" %c", &choice);
    }
    printf("Thank you for shopping!\n");
    float tax = total * 0.07;
    float final_total = total + tax;
    printf("---------------------------\n");
    printf("BILL:-\n");
    printf("Subtotal: $%.2f\n", total);
    printf("Tax (7%%): $%.2f\n", tax);
    printf("Total amount: $%.2f\n", final_total);
    printf("---------------------------\n");
    fclose(menu);
    return 0;
}